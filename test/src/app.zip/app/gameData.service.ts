import { Injectable } from '@angular/core';

@Injectable()
export class gameData {
    getData(){
          return[  
         {"name":"Poleconomy"},
         {"name":"Shengguan"},
         {"name":"Ludo"},
         {"name":"Battle Sheep"},
         {"name":"Blue Max"},
         {"name":"Eclipse"}
          ]
    }
} 